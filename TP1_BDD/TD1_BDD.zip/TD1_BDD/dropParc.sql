use td1_bdd;

drop table Segment;
drop table Salle;
drop table Poste;
drop table Logiciel;
drop table Installer;
drop table Types;