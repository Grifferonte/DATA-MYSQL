use td1_bdd;

describe Segment;
describe Salle;
describe Poste;
describe Logiciel;
describe Installer;
describe Types;